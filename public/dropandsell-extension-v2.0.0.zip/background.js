const CURRENT_VERSION = '2.0.0';

chrome.runtime.onInstalled.addListener(() => {
  console.log('DropandSell Automation App extension installed v' + CURRENT_VERSION);
  checkForUpdate();
});

chrome.runtime.onStartup.addListener(() => {
  checkForUpdate();
});

chrome.alarms.create('updateCheck', { periodInMinutes: 60 });

chrome.alarms.onAlarm.addListener((alarm) => {
  if (alarm.name === 'updateCheck') {
    checkForUpdate();
  }
});

async function checkForUpdate() {
  try {
    const stored = await chrome.storage.local.get(['apiUrl']);
    if (!stored.apiUrl) return;

    const response = await fetch(`${stored.apiUrl}/api/extension/version`, {
      method: 'GET',
      headers: { 'Content-Type': 'application/json' }
    });

    if (!response.ok) return;

    const data = await response.json();
    if (data.version && data.version !== CURRENT_VERSION) {
      await chrome.storage.local.set({
        updateAvailable: true,
        latestVersion: data.version,
        changelog: data.changelog || ''
      });
      chrome.action.setBadgeText({ text: '!' });
      chrome.action.setBadgeBackgroundColor({ color: '#ef4444' });
      console.log('[DropandSell] Update available: v' + data.version);
    } else {
      await chrome.storage.local.set({ updateAvailable: false });
      chrome.action.setBadgeText({ text: '' });
    }
  } catch (e) {
    console.log('[DropandSell] Update check failed:', e.message);
  }
}

chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  if (request.action === 'log') {
    console.log('[DropandSell]', request.message);
  }
  if (request.action === 'checkUpdate') {
    checkForUpdate().then(() => sendResponse({ ok: true }));
    return true;
  }
  return true;
});

// Hostnames that are trusted to hand the extension a fresh set of
// credentials. The manifest's `externally_connectable.matches` is the
// outer gate; this list is a defense-in-depth check inside the listener
// so a compromised wildcard match (e.g. someone's *.replit.app preview)
// cannot silently overwrite a user's saved credentials.
const TRUSTED_CONNECT_HOSTS = [
  'dropandsell.online',
  'www.dropandsell.online',
  'app.dropandsell.online',
];

function isTrustedSenderUrl(url) {
  if (!url || typeof url !== 'string') return false;
  let parsed;
  try {
    parsed = new URL(url);
  } catch (_) {
    return false;
  }
  // Only HTTPS is acceptable for credential transport.
  if (parsed.protocol !== 'https:') return false;
  const host = parsed.hostname.toLowerCase();
  if (TRUSTED_CONNECT_HOSTS.includes(host)) return true;
  if (host.endsWith('.dropandsell.online')) return true;
  return false;
}

// Receives credentials from the DropandSell website's /extension-link page.
// Origin is restricted by the manifest's `externally_connectable.matches`,
// and additionally validated here against TRUSTED_CONNECT_HOSTS.
chrome.runtime.onMessageExternal.addListener((request, sender, sendResponse) => {
  (async () => {
    try {
      if (!isTrustedSenderUrl(sender && sender.url)) {
        console.log('[DropandSell] Rejected external message from untrusted sender:', sender && sender.url);
        sendResponse({ ok: false, message: 'Sender not trusted' });
        return;
      }
      if (!request || request.type !== 'DROPANDSELL_CONNECT') {
        sendResponse({ ok: false, message: 'Unknown message type' });
        return;
      }
      const { apiUrl, uniqueUrl, apiKey } = request.payload || {};
      if (!apiUrl || !uniqueUrl || !apiKey) {
        sendResponse({ ok: false, message: 'Missing credentials' });
        return;
      }

      // The api url MUST be the same origin as the page that sent us the
      // credentials. This prevents a trusted-but-compromised page from
      // pointing the extension at an attacker-controlled backend.
      let payloadUrl;
      try {
        payloadUrl = new URL(String(apiUrl));
      } catch (_) {
        sendResponse({ ok: false, message: 'Invalid apiUrl' });
        return;
      }
      const senderUrl = new URL(sender.url);
      if (payloadUrl.origin !== senderUrl.origin) {
        console.log('[DropandSell] apiUrl origin mismatch:', payloadUrl.origin, 'vs', senderUrl.origin);
        sendResponse({ ok: false, message: 'apiUrl does not match sender origin' });
        return;
      }

      const cleanedUrl = payloadUrl.origin;
      await chrome.storage.local.set({
        apiUrl: cleanedUrl,
        uniqueUrl: String(uniqueUrl),
        apiKey: String(apiKey),
      });

      try {
        chrome.action.setBadgeText({ text: '' });
      } catch (_) {}

      console.log('[DropandSell] Account connected via website link');
      sendResponse({ ok: true });
    } catch (e) {
      console.log('[DropandSell] External connect failed:', e?.message);
      sendResponse({ ok: false, message: e?.message || 'Unknown error' });
    }
  })();
  return true;
});
