// DropandSell Automation App Product Importer Extension v1.7.4
// Content script runs on vendor pages to enable product extraction
console.log('%c[DropandSell v1.7.4] Extension loaded on:', 'color: #3b82f6; font-weight: bold', window.location.hostname);
console.log('[DropandSell] Full URL:', window.location.href);
console.log('[DropandSell] Ready state:', document.readyState);

// Log when the page is fully loaded
if (document.readyState === 'loading') {
  document.addEventListener('DOMContentLoaded', () => {
    console.log('[DropandSell] DOM content loaded');
  });
}

window.addEventListener('load', () => {
  console.log('[DropandSell] Page fully loaded, ready to extract product data');
});
