# DropandSell Automation App

DropandSell is a multi-tenant SaaS platform that automates dropshipping operations for e-commerce businesses across various marketplaces.

## Run & Operate

**Required Environment Variables:**
- `DATABASE_URL`: PostgreSQL connection string
- `REPLIT_AUTH_CLIENT_ID`, `REPLIT_AUTH_CLIENT_SECRET`: For Replit Auth
- `STRIPE_SECRET_KEY`, `STRIPE_WEBHOOK_SECRET`: For Stripe integration
- `OPENAI_API_KEY`: For AI functionalities
- `RESEND_API_KEY`: For email services
- Marketplace API keys/secrets (e.g., `SHOPIFY_API_KEY`, `EBAY_CLIENT_ID`, `AMAZON_SP_CLIENT_ID`, `TIKTOK_SHOP_APP_KEY`, `JUMIA_API_KEY`)

**Commands:**
- `npm install`: Install dependencies
- `npm run dev`: Run the development server
- `npm run build`: Build the application
- `npm run typecheck`: Run TypeScript type checking
- `npm run codegen`: Generate Zod schemas from Drizzle ORM
- `npm run db:push`: Apply database migrations

## Stack

- **Frontend**: React 18 (TypeScript), Wouter, TanStack React Query, shadcn/ui (Radix UI, Tailwind CSS), React Hook Form, Zod, Vite
- **Backend**: Express.js (TypeScript), Drizzle ORM, Zod, Passport.js (Replit Auth), express-session
- **Database**: PostgreSQL
- **Build Tool**: Vite

## Where things live

- `client/`: Frontend application code
- `server/`: Backend application code
- `db/schema.ts`: Database schema definition (source-of-truth)
- `server/api/`: REST API route definitions and handlers
- `shared/types/`: Shared TypeScript types and API contracts (source-of-truth)
- `client/src/components/ui/`: UI components (shadcn/ui)
- `client/src/lib/`: Frontend utility functions and hooks
- `server/storage/`: Database interaction logic via Drizzle ORM
- `server/middleware/`: Express middleware
- `server/auth/`: Authentication strategies
- `chrome-extension/`: Chrome extension source code

## Architecture decisions

- **Shared Type Safety**: API request/response contracts and database schemas are defined once using Zod and Drizzle, then shared between frontend and backend to ensure end-to-end type safety.
- **Multi-tenancy via `userId`**: User data is isolated at the database level by enforcing `userId` foreign keys on all relevant tables, ensuring one user cannot access another's data.
- **Storage Abstraction**: Database operations are encapsulated behind an `IStorage` interface, promoting testability and allowing for potential future database changes.
- **Server-Proxied Marketplace Interactions**: For security and token management, all marketplace API calls (e.g., eBay, Shopify) made on behalf of a user are routed through the backend, preventing direct client-side exposure of sensitive credentials.
- **Atomic Listing Slot Reservation**: A robust, single-SQL atomic reservation mechanism is implemented for Drop-and-Sell listing slots to prevent race conditions and over-publishing beyond a purchased quota.

## Product

- **Marketplace Integrations**: Connects to Shopify, eBay, Amazon, TikTok Shop, and Jumia for product listing and order management.
- **Automated Fulfillment**: End-to-end order processing from ingestion to tracking sync.
- **Pricing Engine**: Configurable rules for markup, margin, and min/max pricing.
- **Product Management**: Manual entry, AI-generated descriptions, CSV import, and batch publishing.
- **Live Vendor Tracking**: Real-time stock and price updates from vendor websites, supported by a Chrome extension.
- **Subscription & Referral Systems**: Stripe-based billing and a referral program with wallet integration.
- **Internationalization**: Supports 39 languages with RTL support.
- **Dashboard & Analytics**: Provides key statistics, recent orders, and store-filtered charts.
- **Drop-and-Sell Lister Workflow**: Allows freelancers to list products directly into customer eBay stores with automated SKU mapping for fulfillment.

## User preferences

Preferred communication style: Simple, everyday language.

## Gotchas

- Always run `npm run codegen` after modifying Drizzle schemas (`db/schema.ts`) to update Zod schemas for validation.
- Ensure all required environment variables are set before running the application, especially for marketplace integrations and payment processing.
- When working with Drop-and-Sell listings, always verify the `sku_mappings` exist and are correct to ensure auto-fulfillment functions as expected.
- Be mindful of the atomic listing slot reservation mechanism; failures during the listing process should trigger rollback to prevent orphaned products or leaked slots.

## Pointers

- **React Query Documentation**: `https://tanstack.com/query/latest/docs/react/overview`
- **Drizzle ORM Documentation**: `https://orm.drizzle.team/docs/overview`
- **shadcn/ui Documentation**: `https://ui.shadcn.com/docs`
- **Tailwind CSS Documentation**: `https://tailwindcss.com/docs`
- **Replit Auth Documentation**: _Populate as you build_
- **Stripe API Documentation**: `https://stripe.com/docs/api`
- **OpenAI API Documentation**: `https://platform.openai.com/docs/overview`
- **Zod Documentation**: `https://zod.dev/`